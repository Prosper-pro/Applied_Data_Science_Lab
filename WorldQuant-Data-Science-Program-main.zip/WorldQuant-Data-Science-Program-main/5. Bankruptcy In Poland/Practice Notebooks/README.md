# 050-bankruptcy-in-poland
## Concepts learnt
- Working with JSON
- Imbalanced data
- Random forest
- Gradient boosting
- Linux command line
- Creating python modules
- Importing functions from modules
- Saving and loading a model
