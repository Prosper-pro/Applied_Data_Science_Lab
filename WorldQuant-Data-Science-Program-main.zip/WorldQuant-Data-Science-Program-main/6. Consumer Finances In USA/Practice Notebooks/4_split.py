import libraries
import 1_import
import 2_explore
import 3_explore

# Feature matrix X containing five columns in high_var_cols
X = df_small_biz[high_var_cols]
