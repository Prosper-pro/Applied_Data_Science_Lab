corr1= homes_by_state["area_m2"].corr(homes_by_state["price_usd"])

0.5773267433717683 # more than half 
