## 070-ds-admissions-in-wqu

### Contents...
> EDA.

> ETL.

> Chi-Square test.

> Interactive dashboard.


![image](https://user-images.githubusercontent.com/99328720/189812167-668064f1-7ee3-4a5c-9ae7-638101e5e9f9.png)



![image](https://user-images.githubusercontent.com/99328720/189812222-a33a9bee-42cf-481e-a3d1-047cb69859e8.png)
