# 020-housing-in-buenos-aires/025-assignment.ipynb

New concepts learnt in this project
