from pprint import PrettyPrinter

# Instantiate prettyprinter ----> for nicely formatted output
pp = PrettyPrinter(indent=2)
