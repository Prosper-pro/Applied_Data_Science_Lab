# 030-Air-Quality-In-Nairobi

- Data wrangling with MongoDB
- LinearRegression with time Series data
- Autoregressive models
- ARMA models and Hyperparameter tuning
